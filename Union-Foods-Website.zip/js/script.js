/**
 * UNION FOODS - PRODUCTION JAVASCRIPT
 * Pure Vanilla JavaScript (ES6+) - Zero External Frameworks
 * 45+ Functional Interactive Features & Mobile-First Handlers
 */

(function () {
  'use strict';

  /* ==========================================================================
     1. GLOBAL DATA & MOCK REPOSITORY
     ========================================================================== */
  const PRODUCTS_DATA = [
    {
      id: 'uf-oil-1',
      name: 'Refined Sunflower Oil',
      category: 'oil',
      categoryName: 'Cooking Oil',
      volume: '1 Litre',
      price: 145,
      originalPrice: 175,
      rating: 4.9,
      reviews: 1420,
      image: 'assets/images/prod-oil.jpg',
      featured: true,
      description: 'Triple refined, 100% pure sunflower oil enriched with Vitamin A & D. Light, healthy, and cholesterol-free for everyday family cooking.',
      nutrition: { energy: '900 kcal', fat: '100g', saturates: '11g', transFat: '0g', cholesterol: '0mg' },
      dietary: ['heart-healthy', 'cholesterol-free', 'vitamin-enriched'],
      packSizes: ['500 ml', '1 Litre', '5 Litre Jar']
    },
    {
      id: 'uf-atta-1',
      name: 'Premium Sharbati Atta',
      category: 'flour',
      categoryName: 'Flour & Grains',
      volume: '5 Kg',
      price: 245,
      originalPrice: 280,
      rating: 4.8,
      reviews: 2150,
      image: 'assets/images/prod-atta.jpg',
      featured: true,
      description: '100% whole wheat chakki fresh flour milled from golden Sharbati grains. Makes rotis that stay soft, fluffy, and aromatic for hours.',
      nutrition: { energy: '360 kcal', protein: '12g', carbs: '72g', fiber: '11g', fat: '1.7g' },
      dietary: ['high-fiber', '100%-whole-wheat', 'zero-maida'],
      packSizes: ['1 Kg', '5 Kg', '10 Kg Saver']
    },
    {
      id: 'uf-moong-1',
      name: 'Unpolished Moong Dal',
      category: 'pulses',
      categoryName: 'Pulses & Dal',
      volume: '1 Kg',
      price: 135,
      originalPrice: 160,
      rating: 4.9,
      reviews: 980,
      image: 'assets/images/prod-dal.jpg',
      featured: true,
      description: 'Premium unpolished yellow moong lentils with natural nutrients and wholesome flavor intact. Easy to digest and rich in plant protein.',
      nutrition: { energy: '348 kcal', protein: '24g', carbs: '60g', fiber: '8g', iron: '4.8mg' },
      dietary: ['high-protein', 'unpolished', 'easy-digest'],
      packSizes: ['500 g', '1 Kg', '2 Kg']
    },
    {
      id: 'uf-chana-1',
      name: 'Desi Chana Dal',
      category: 'pulses',
      categoryName: 'Pulses & Dal',
      volume: '1 Kg',
      price: 115,
      originalPrice: 140,
      rating: 4.7,
      reviews: 860,
      image: 'assets/images/prod-dal.jpg',
      featured: true,
      description: 'Selected naturally grown desi Bengal gram pulses cleaned through 5-stage optical sortex technology. Delivers rich aroma and thick texture.',
      nutrition: { energy: '372 kcal', protein: '21g', carbs: '59g', fiber: '15g', iron: '5.3mg' },
      dietary: ['low-gi', 'high-protein', 'sortex-cleaned'],
      packSizes: ['500 g', '1 Kg', '2 Kg']
    },
    {
      id: 'uf-mustard-1',
      name: 'Kachi Ghani Mustard Oil',
      category: 'oil',
      categoryName: 'Cooking Oil',
      volume: '1 Litre',
      price: 155,
      originalPrice: 185,
      rating: 4.8,
      reviews: 640,
      image: 'assets/images/prod-oil.jpg',
      featured: false,
      description: 'Traditional cold-pressed raw mustard oil with pungent kick and natural antioxidants. Perfect for authentic regional fish curries and pickles.',
      nutrition: { energy: '884 kcal', fat: '100g', omega3: '8.5g', mufa: '65g' },
      dietary: ['cold-pressed', 'omega-3', 'pungent-authentic'],
      packSizes: ['500 ml', '1 Litre', '5 Litre Jar']
    },
    {
      id: 'uf-toor-1',
      name: 'Organic Toor Dal',
      category: 'pulses',
      categoryName: 'Pulses & Dal',
      volume: '1 Kg',
      price: 165,
      originalPrice: 195,
      rating: 4.9,
      reviews: 1120,
      image: 'assets/images/prod-dal.jpg',
      featured: false,
      description: 'Naturally sun-dried pigeon peas, unpolished and free from artificial coloring or polishing oils. Yields delicious, creamy Indian dal.',
      nutrition: { energy: '343 kcal', protein: '22g', carbs: '63g', fiber: '15g' },
      dietary: ['100%-organic', 'unpolished', 'high-protein'],
      packSizes: ['500 g', '1 Kg', '2 Kg']
    },
    {
      id: 'uf-haldi-1',
      name: 'Pure Turmeric Powder',
      category: 'spices',
      categoryName: 'Spices',
      volume: '500 g',
      price: 95,
      originalPrice: 120,
      rating: 4.9,
      reviews: 530,
      image: 'assets/images/prod-spices.jpg',
      featured: false,
      description: 'Ground from premium hand-picked turmeric fingers from Kandhamal with high natural curcumin content (>3.8%). Gives golden glow and immunity boost.',
      nutrition: { curcumin: '3.8%+', purity: '100%', moisture: '<10%' },
      dietary: ['high-curcumin', 'kandhamal-gi', 'zero-additives'],
      packSizes: ['200 g', '500 g', '1 Kg']
    },
    {
      id: 'uf-snacks-1',
      name: 'Crispy Moong Dal Namkeen',
      category: 'snacks',
      categoryName: 'Snacks & Namkeen',
      volume: '400 g',
      price: 85,
      originalPrice: 105,
      rating: 4.8,
      reviews: 420,
      image: 'assets/images/prod-snacks.jpg',
      featured: true,
      description: 'Crispy, protein-packed roasted and seasoned moong lentils prepared in cold-pressed oil with traditional spices. Zero palm oil, 100% wholesome snacking.',
      nutrition: { energy: '460 kcal', protein: '19g', carbs: '52g', fiber: '6g', fat: '20g' },
      dietary: ['zero-palm-oil', 'high-protein', 'crispy-roasted'],
      packSizes: ['200 g', '400 g', '1 Kg Family Pack']
    }
  ];

  const BATCH_TRACES = {
    'UF-2026-WHEAT': {
      product: 'Union Foods Premium Sharbati Atta (5 Kg)',
      farmerCoop: 'Kalinga Krushak Samiti, Sambalpur District, Odisha',
      harvestDate: 'Oct 12, 2026',
      millingDate: 'Oct 26, 2026',
      facility: 'Union Foods Unit-2, Mancheswar IE, Bhubaneswar',
      purityScore: '99.94% Grain Purity',
      labReport: 'Certified Zero Pesticide Residue & Zero Moisture Spoilage',
      status: 'Verified Pure & Safe'
    },
    'UF-2026-OIL': {
      product: 'Union Foods Refined Sunflower Oil (1 Litre)',
      farmerCoop: 'Rayagada Agro Oilseeds Consortium, Odisha',
      harvestDate: 'Sep 28, 2026',
      millingDate: 'Oct 20, 2026',
      facility: 'Union Foods Unit-1, Chandaka Industrial Area, Bhubaneswar',
      purityScore: '100% Free of Argemone Oil & Trans Fats',
      labReport: 'FSSAI Certified Lab Tested (Audit #2026-OD-881)',
      status: 'Approved Premium Grade'
    },
    'UF-2026-DAL': {
      product: 'Union Foods Unpolished Moong Dal (1 Kg)',
      farmerCoop: 'Bargarh Pulse Growers Network, Odisha',
      harvestDate: 'Oct 05, 2026',
      millingDate: 'Oct 24, 2026',
      facility: 'Union Foods Unit-1, Bhubaneswar',
      purityScore: '100% Unpolished & Water Cleaned',
      labReport: 'Zero Added Synthetic Wax or Lead Chromate',
      status: 'High Protein Certified'
    }
  };

  const RECIPES_DATA = {
    curry: {
      title: 'Healthy Vegetable Kadai with Union Foods Atta Rotis',
      prepTime: '25 Mins',
      cookTime: '30 Mins',
      servings: 4,
      calories: '280 kcal/serving',
      ingredients: [
        { name: 'Union Foods Premium Sharbati Atta', baseQty: 2, unit: 'cups' },
        { name: 'Union Foods Refined Sunflower Oil', baseQty: 2, unit: 'tbsp' },
        { name: 'Diced Paneer or Tofu', baseQty: 200, unit: 'g' },
        { name: 'Mixed Veggies (Bell peppers, peas, carrots)', baseQty: 2, unit: 'cups' },
        { name: 'Union Foods Pure Turmeric Powder', baseQty: 0.5, unit: 'tsp' },
        { name: 'Chopped Onions & Pureed Fresh Tomatoes', baseQty: 1.5, unit: 'cups' },
        { name: 'Fresh Coriander & Garam Masala', baseQty: 1, unit: 'tsp' }
      ],
      steps: [
        'Knead Union Foods Atta with warm water and 1 tsp oil into a soft dough. Rest for 15 minutes.',
        'Heat 2 tbsp Union Foods Sunflower Oil in a kadai. Sauté onions and ginger-garlic paste till golden.',
        'Add tomato puree, turmeric powder, and spices. Cook till oil separates aromatically.',
        'Add diced vegetables and paneer. Simmer for 10 minutes on low heat.',
        'Roll dough into thin rotis and puff them on a hot tawa. Serve steaming hot!'
      ]
    }
  };

  const CUSTOMER_REVIEWS = [
    {
      quote: 'Union Foods products are always fresh, high quality and trusted by our family. The taste and purity are truly excellent.',
      name: 'Priya Mishra',
      location: 'Bhubaneswar, Odisha',
      rating: 5,
      avatar: 'assets/images/priya-avatar.svg'
    },
    {
      quote: 'The Sharbati Atta is super soft and rotis stay fresh till evening. Sunflower oil is remarkably light with zero oily smell!',
      name: 'Rajesh Mohapatra',
      location: 'Cuttack, Odisha',
      rating: 5,
      avatar: 'assets/images/priya-avatar.svg'
    },
    {
      quote: 'We order pulses in bulk every month. The unpolished moong and toor dal cook quickly and taste like authentic farm produce.',
      name: 'Sunita Patnaik',
      location: 'Rourkela, Odisha',
      rating: 5,
      avatar: 'assets/images/priya-avatar.svg'
    }
  ];

  /* ==========================================================================
     2. APPLICATION STATE (WITH LOCALSTORAGE PERSISTENCE)
     ========================================================================== */
  const AppState = {
    cart: JSON.parse(localStorage.getItem('uf_cart') || '[]'),
    wishlist: JSON.parse(localStorage.getItem('uf_wishlist') || '[]'),
    appliedCoupon: JSON.parse(localStorage.getItem('uf_coupon') || 'null'),
    currentCategory: 'all',
    currentSort: 'popular',
    soundEnabled: true,
    theme: localStorage.getItem('uf_theme') || 'light',
    currentLanguage: localStorage.getItem('uf_lang') || 'en'
  };

  function saveCart() {
    localStorage.setItem('uf_cart', JSON.stringify(AppState.cart));
    updateCartUI();
  }

  function saveWishlist() {
    localStorage.setItem('uf_wishlist', JSON.stringify(AppState.wishlist));
    updateWishlistUI();
  }

  /* ==========================================================================
     3. AUDIO FEEDBACK (WEB AUDIO API)
     ========================================================================== */
  function playAudioFeedback(type = 'click') {
    if (!AppState.soundEnabled) return;
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'add') {
        osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
        osc.frequency.exponentialRampToValueAtTime(783.99, ctx.currentTime + 0.12); // G5
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
        osc.start();
        osc.stop(ctx.currentTime + 0.15);
      } else if (type === 'celebrate') {
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.25);
        gain.gain.setValueAtTime(0.15, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
        osc.start();
        osc.stop(ctx.currentTime + 0.3);
      } else {
        osc.frequency.setValueAtTime(600, ctx.currentTime);
        gain.gain.setValueAtTime(0.05, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.05);
        osc.start();
        osc.stop(ctx.currentTime + 0.05);
      }
    } catch (e) {
      // Audio not permitted without user gesture, silently pass
    }
  }

  /* ==========================================================================
     4. TOAST NOTIFICATION ENGINE
     ========================================================================== */
  function showToast(message, type = 'info', duration = 3200) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    let icon = `
      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15h2v-6h-2v6zm0-8h2V7h-2v2z"/>
      </svg>`;
    if (type === 'success') {
      icon = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="#22c55e">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
        </svg>`;
    } else if (type === 'error') {
      icon = `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="#ef4444">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/>
        </svg>`;
    }

    toast.innerHTML = `${icon}<span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }

  /* ==========================================================================
     5. NAVIGATION & STICKY SCROLL SPY
     ========================================================================== */
  function initNavigation() {
    const header = document.querySelector('.main-header');
    const scrollBar = document.getElementById('scroll-progress');
    const backToTopBtn = document.getElementById('back-to-top-btn');
    const scrollRingCircle = document.querySelector('.scroll-ring-circle');
    const hamburgerBtn = document.getElementById('hamburger-toggle');
    const mobileNav = document.getElementById('desktop-nav');
    const navLinks = document.querySelectorAll('.nav-link[href^="#"]');
    const sections = document.querySelectorAll('section[id]');

    // Scroll Handler
    window.addEventListener('scroll', () => {
      const scrollY = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      const progress = docHeight > 0 ? (scrollY / docHeight) * 100 : 0;

      // Sticky Header
      if (scrollY > 50) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }

      // Scroll Progress Bar
      if (scrollBar) {
        scrollBar.style.width = `${progress}%`;
      }

      // Back to Top Button & Circular Progress
      if (backToTopBtn) {
        if (scrollY > 350) {
          backToTopBtn.classList.add('visible');
        } else {
          backToTopBtn.classList.remove('visible');
        }
        if (scrollRingCircle) {
          const circumference = 145; // 2 * pi * r (approx)
          const offset = circumference - (progress / 100) * circumference;
          scrollRingCircle.style.strokeDashoffset = offset;
        }
      }

      // Active Section Highlighting (Scroll Spy)
      let currentSectionId = '';
      sections.forEach(section => {
        const top = section.offsetTop - 120;
        const height = section.offsetHeight;
        if (scrollY >= top && scrollY < top + height) {
          currentSectionId = section.getAttribute('id');
        }
      });

      navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${currentSectionId}`) {
          link.classList.add('active');
        }
      });
    }, { passive: true });

    // Back to top click
    if (backToTopBtn) {
      backToTopBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        playAudioFeedback('click');
      });
    }

    // Mobile Hamburger Toggle
    if (hamburgerBtn && mobileNav) {
      hamburgerBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        const isOpen = mobileNav.classList.toggle('active');
        hamburgerBtn.classList.toggle('active');
        hamburgerBtn.setAttribute('aria-expanded', isOpen);
        playAudioFeedback('click');
      });

      // Close menu on link click
      navLinks.forEach(link => {
        link.addEventListener('click', () => {
          mobileNav.classList.remove('active');
          hamburgerBtn.classList.remove('active');
          hamburgerBtn.setAttribute('aria-expanded', 'false');
        });
      });

      // Close menu on outside click
      document.addEventListener('click', (e) => {
        if (mobileNav.classList.contains('active') && !mobileNav.contains(e.target) && !hamburgerBtn.contains(e.target)) {
          mobileNav.classList.remove('active');
          hamburgerBtn.classList.remove('active');
          hamburgerBtn.setAttribute('aria-expanded', 'false');
        }
      });

      // Close menu on Escape key press
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && mobileNav.classList.contains('active')) {
          mobileNav.classList.remove('active');
          hamburgerBtn.classList.remove('active');
          hamburgerBtn.setAttribute('aria-expanded', 'false');
        }
      });
    }
  }

  /* ==========================================================================
     6. THEME TOGGLE (DARK / LIGHT) & LANGUAGE SWITCHER
     ========================================================================== */
  function initThemeAndLanguage() {
    const themeBtn = document.getElementById('theme-toggle-btn');
    const langBtn = document.getElementById('lang-toggle-btn');

    // Apply initial theme
    if (AppState.theme === 'dark') {
      document.documentElement.setAttribute('data-theme', 'dark');
    }

    if (themeBtn) {
      themeBtn.addEventListener('click', () => {
        const current = document.documentElement.getAttribute('data-theme');
        const next = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        AppState.theme = next;
        localStorage.setItem('uf_theme', next);
        showToast(`Theme switched to ${next} mode`, 'info');
        playAudioFeedback('click');
      });
    }

    if (langBtn) {
      const langs = ['EN', 'HI', 'OD'];
      langBtn.addEventListener('click', () => {
        let idx = langs.indexOf(AppState.currentLanguage.toUpperCase());
        idx = (idx + 1) % langs.length;
        const nextLang = langs[idx];
        AppState.currentLanguage = nextLang.toLowerCase();
        localStorage.setItem('uf_lang', AppState.currentLanguage);
        langBtn.querySelector('span').textContent = nextLang;
        showToast(`Language set to ${nextLang === 'OD' ? 'Odia (ଓଡ଼ିଆ)' : nextLang === 'HI' ? 'Hindi (हिन्दी)' : 'English'}`, 'success');
        playAudioFeedback('click');
      });
    }
  }

  /* ==========================================================================
     7. PRODUCT CATALOG & CATEGORY FILTERING ENGINE
     ========================================================================== */
  function renderProducts(items, containerId = 'catalog-grid') {
    const container = document.getElementById(containerId);
    if (!container) return;

    if (items.length === 0) {
      container.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 3rem 1rem; color: var(--text-muted);">
          <p style="font-size: 1.1rem; font-weight: 700; margin-bottom: 0.5rem;">No products found</p>
          <p style="font-size: 0.9rem;">Try selecting a different category or clearing your search term.</p>
        </div>`;
      return;
    }

    container.innerHTML = items.map(product => {
      const isWishlisted = AppState.wishlist.includes(product.id);
      return `
        <div class="product-card" data-id="${product.id}" data-category="${product.category}">
          <!-- Official Union Foods Logo Brand Badge -->
          <div class="product-brand-stamp" title="Union Foods Certified Quality">
            <img src="assets/images/union-foods-logo.png" alt="Union Foods Quality Seal" class="product-stamp-img">
            <span class="product-stamp-text">Union Foods</span>
          </div>
          <button class="wishlist-heart-btn ${isWishlisted ? 'active' : ''}" 
                  data-wishlist-id="${product.id}" 
                  title="${isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}" 
                  aria-label="Wishlist">
            <svg viewBox="0 0 24 24">
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
            </svg>
          </button>
          
          <div class="product-img-box" onclick="window.UnionFoods.openQuickView('${product.id}')" style="cursor: pointer;">
            <img src="${product.image}" alt="${product.name}" loading="lazy">
          </div>
          
          <div class="product-meta-header">
            <h3 class="product-title">${product.name}</h3>
            <span class="product-volume">${product.volume}</span>
          </div>
          
          <div class="product-price-row">
            <span class="product-price-current">₹${product.price}</span>
            <span class="product-price-original">₹${product.originalPrice}</span>
          </div>
          
          <div class="product-actions-group">
            <button class="btn-view-product" onclick="window.UnionFoods.openQuickView('${product.id}')">
              <span>View Product</span>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                <path d="M8.59 16.59L13.17 12 8.59 7.41 10 6l6 6-6 6-1.41-1.41z"/>
              </svg>
            </button>
            <button class="btn-quick-add" onclick="window.UnionFoods.addToCart('${product.id}', 1)" title="Add to Cart">
              <svg viewBox="0 0 24 24">
                <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
              </svg>
            </button>
          </div>
        </div>`;
    }).join('');
  }

  function filterAndSortProducts() {
    let list = [...PRODUCTS_DATA];

    // Filter by Category
    if (AppState.currentCategory !== 'all') {
      list = list.filter(item => item.category === AppState.currentCategory);
    }

    // Sort
    if (AppState.currentSort === 'price-low') {
      list.sort((a, b) => a.price - b.price);
    } else if (AppState.currentSort === 'price-high') {
      list.sort((a, b) => b.price - a.price);
    } else if (AppState.currentSort === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    } else if (AppState.currentSort === 'name') {
      list.sort((a, b) => a.name.localeCompare(b.name));
    }

    renderProducts(list, 'catalog-grid');
  }

  function initCategoryFilters() {
    // 7 Reference Category Cards click
    const categoryCards = document.querySelectorAll('.category-card[data-cat]');
    categoryCards.forEach(card => {
      card.addEventListener('click', () => {
        categoryCards.forEach(c => c.classList.remove('active'));
        card.classList.add('active');

        const cat = card.getAttribute('data-cat');
        AppState.currentCategory = cat;

        // Also synchronize catalog filter tabs if visible
        const tabBtns = document.querySelectorAll('.filter-tab-btn');
        tabBtns.forEach(btn => {
          btn.classList.toggle('active', btn.getAttribute('data-filter') === cat);
        });

        filterAndSortProducts();
        playAudioFeedback('click');

        // Smooth scroll towards the catalog section
        const catalogSec = document.getElementById('products-section');
        if (catalogSec) {
          catalogSec.scrollIntoView({ behavior: 'smooth' });
        }
      });
    });

    // Catalog Filter Buttons
    const tabBtns = document.querySelectorAll('.filter-tab-btn');
    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        tabBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const filter = btn.getAttribute('data-filter');
        AppState.currentCategory = filter;
        filterAndSortProducts();
        playAudioFeedback('click');
      });
    });

    // Sort Dropdown
    const sortSelect = document.getElementById('catalog-sort-select');
    if (sortSelect) {
      sortSelect.addEventListener('change', (e) => {
        AppState.currentSort = e.target.value;
        filterAndSortProducts();
      });
    }
  }

  /* ==========================================================================
     8. CART & WISHLIST LOGIC
     ========================================================================== */
  function addToCart(productId, qty = 1, size = null) {
    const product = PRODUCTS_DATA.find(p => p.id === productId);
    if (!product) return;

    const chosenSize = size || product.volume;
    const cartItemId = `${product.id}-${chosenSize}`;
    const existingIndex = AppState.cart.findIndex(item => item.cartItemId === cartItemId);

    if (existingIndex > -1) {
      AppState.cart[existingIndex].qty += qty;
    } else {
      AppState.cart.push({
        cartItemId,
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        volume: chosenSize,
        qty: qty
      });
    }

    saveCart();
    playAudioFeedback('add');
    showToast(`Added ${product.name} (${chosenSize}) to cart!`, 'success');

    // Automatically reveal drawer
    openCartDrawer();
  }

  function updateCartQuantity(cartItemId, delta) {
    const item = AppState.cart.find(i => i.cartItemId === cartItemId);
    if (!item) return;

    item.qty += delta;
    if (item.qty <= 0) {
      AppState.cart = AppState.cart.filter(i => i.cartItemId !== cartItemId);
      showToast('Item removed from cart', 'info');
    }
    saveCart();
    playAudioFeedback('click');
  }

  function removeFromCart(cartItemId) {
    AppState.cart = AppState.cart.filter(i => i.cartItemId !== cartItemId);
    saveCart();
    playAudioFeedback('click');
    showToast('Item removed from cart', 'info');
  }

  function calculateCartTotals() {
    const subtotal = AppState.cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    const freeDeliveryThreshold = 499;
    const deliveryFee = subtotal >= freeDeliveryThreshold || subtotal === 0 ? 0 : 50;

    let discount = 0;
    if (AppState.appliedCoupon) {
      if (AppState.appliedCoupon.type === 'percent') {
        discount = Math.round(subtotal * (AppState.appliedCoupon.value / 100));
      } else if (AppState.appliedCoupon.type === 'shipping') {
        discount = deliveryFee;
      }
    }

    const total = Math.max(0, subtotal + deliveryFee - discount);
    return { subtotal, deliveryFee, discount, total, freeDeliveryThreshold };
  }

  function updateCartUI() {
    const badge = document.getElementById('cart-count-badge');
    const drawerContainer = document.getElementById('cart-items-container');
    const subtotalEl = document.getElementById('cart-subtotal');
    const shippingEl = document.getElementById('cart-shipping');
    const discountEl = document.getElementById('cart-discount');
    const totalEl = document.getElementById('cart-total');
    const freeShippingText = document.getElementById('free-shipping-text');
    const freeShippingFill = document.getElementById('free-shipping-fill');

    const totalQty = AppState.cart.reduce((sum, item) => sum + item.qty, 0);

    if (badge) {
      badge.textContent = totalQty;
      badge.classList.add('bump');
      setTimeout(() => badge.classList.remove('bump'), 250);
    }

    const { subtotal, deliveryFee, discount, total, freeDeliveryThreshold } = calculateCartTotals();

    // Free delivery meter
    if (freeShippingText && freeShippingFill) {
      if (subtotal >= freeDeliveryThreshold) {
        freeShippingText.textContent = '🎉 You have unlocked FREE Express Delivery!';
        freeShippingFill.style.width = '100%';
      } else {
        const remaining = freeDeliveryThreshold - subtotal;
        freeShippingText.textContent = `Add ₹${remaining} more for FREE Express Delivery!`;
        const pct = Math.min(100, Math.round((subtotal / freeDeliveryThreshold) * 100));
        freeShippingFill.style.width = `${pct}%`;
      }
    }

    if (subtotalEl) subtotalEl.textContent = `₹${subtotal}`;
    if (shippingEl) shippingEl.textContent = deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`;
    if (discountEl) discountEl.textContent = discount > 0 ? `-₹${discount}` : '₹0';
    if (totalEl) totalEl.textContent = `₹${total}`;

    // Render Items in Drawer
    if (drawerContainer) {
      if (AppState.cart.length === 0) {
        drawerContainer.innerHTML = `
          <div style="text-align: center; padding: 3rem 1rem; color: var(--text-muted);">
            <svg width="60" height="60" viewBox="0 0 24 24" fill="#cbd5e1" style="margin: 0 auto 1rem;">
              <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/>
            </svg>
            <h4 style="font-size: 1.1rem; color: var(--text-heading); margin-bottom: 0.35rem;">Your Cart is Empty</h4>
            <p style="font-size: 0.85rem; margin-bottom: 1.5rem;">Explore our range of 100% natural, hygienic food products.</p>
            <button class="btn-primary" onclick="window.UnionFoods.closeCartDrawer();">Start Shopping</button>
          </div>`;
      } else {
        drawerContainer.innerHTML = AppState.cart.map(item => `
          <div class="cart-item-row">
            <div class="cart-item-thumb">
              <img src="${item.image}" alt="${item.name}">
            </div>
            <div class="cart-item-info">
              <h4 class="cart-item-title">${item.name}</h4>
              <span style="font-size: 0.76rem; color: var(--text-muted);">${item.volume}</span>
              <div class="cart-item-price">₹${item.price * item.qty}</div>
            </div>
            <div class="cart-qty-ctrls">
              <button class="qty-btn" onclick="window.UnionFoods.updateQty('${item.cartItemId}', -1)">-</button>
              <span class="qty-val">${item.qty}</span>
              <button class="qty-btn" onclick="window.UnionFoods.updateQty('${item.cartItemId}', 1)">+</button>
            </div>
            <button style="color: #94a3b8; font-size: 1.2rem; padding: 0.3rem;" onclick="window.UnionFoods.removeItem('${item.cartItemId}')" title="Delete">
              &times;
            </button>
          </div>
        `).join('');
      }
    }
  }

  function openCartDrawer() {
    const overlay = document.getElementById('cart-drawer-overlay');
    const drawer = document.getElementById('cart-drawer');
    if (overlay && drawer) {
      overlay.classList.add('active');
      drawer.classList.add('active');
    }
  }

  function closeCartDrawer() {
    const overlay = document.getElementById('cart-drawer-overlay');
    const drawer = document.getElementById('cart-drawer');
    if (overlay && drawer) {
      overlay.classList.remove('active');
      drawer.classList.remove('active');
    }
  }

  // Wishlist Toggle
  function toggleWishlist(productId) {
    const idx = AppState.wishlist.indexOf(productId);
    if (idx > -1) {
      AppState.wishlist.splice(idx, 1);
      showToast('Removed from Wishlist', 'info');
    } else {
      AppState.wishlist.push(productId);
      showToast('Saved to your Wishlist!', 'success');
      playAudioFeedback('add');
    }
    saveWishlist();
  }

  function updateWishlistUI() {
    const btns = document.querySelectorAll('.wishlist-heart-btn');
    btns.forEach(btn => {
      const pid = btn.getAttribute('data-wishlist-id');
      btn.classList.toggle('active', AppState.wishlist.includes(pid));
    });
  }

  /* ==========================================================================
     9. SECTION 17: PROMOTIONAL OFFERS SLIDER CONTROLS & COUNTDOWN TIMER
     ========================================================================== */
  function initOffersSlider() {
    const track = document.getElementById('offers-carousel-track');
    const prevBtn = document.getElementById('offer-prev-btn');
    const nextBtn = document.getElementById('offer-next-btn');

    if (track && prevBtn && nextBtn) {
      prevBtn.addEventListener('click', () => {
        track.scrollBy({ left: -320, behavior: 'smooth' });
        playAudioFeedback('click');
      });
      nextBtn.addEventListener('click', () => {
        track.scrollBy({ left: 320, behavior: 'smooth' });
        playAudioFeedback('click');
      });
    }

    // Live ticking countdown timer for offers
    function updateOfferCountdown() {
      const now = new Date();
      // Countdown to midnight tonight
      const midnight = new Date();
      midnight.setHours(23, 59, 59, 999);
      const diff = midnight - now;

      const hours = Math.floor(diff / (1000 * 60 * 60)).toString().padStart(2, '0');
      const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)).toString().padStart(2, '0');
      const secs = Math.floor((diff % (1000 * 60)) / 1000).toString().padStart(2, '0');

      const timerElements = document.querySelectorAll('.offer-countdown-val');
      timerElements.forEach(el => {
        el.textContent = `${hours}h ${mins}m ${secs}s`;
      });
    }
    setInterval(updateOfferCountdown, 1000);
    updateOfferCountdown();
  }

  /* ==========================================================================
     10. TESTIMONIALS CAROUSEL
     ========================================================================== */
  let currentReviewIdx = 0;
  function updateTestimonialUI(idx) {
    currentReviewIdx = (idx + CUSTOMER_REVIEWS.length) % CUSTOMER_REVIEWS.length;
    const review = CUSTOMER_REVIEWS[currentReviewIdx];

    const quoteEl = document.getElementById('testimonial-quote-text');
    const nameEl = document.getElementById('testimonial-author-name');
    const locEl = document.getElementById('testimonial-author-loc');

    if (quoteEl && nameEl && locEl) {
      quoteEl.style.opacity = '0';
      quoteEl.style.transform = 'translateY(8px)';
      setTimeout(() => {
        quoteEl.textContent = `"${review.quote}"`;
        nameEl.textContent = review.name;
        locEl.textContent = review.location;
        quoteEl.style.opacity = '1';
        quoteEl.style.transform = 'translateY(0)';
      }, 180);
    }
  }

  function initTestimonialsCarousel() {
    const prevBtn = document.getElementById('testi-prev-btn');
    const nextBtn = document.getElementById('testi-next-btn');

    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        updateTestimonialUI(currentReviewIdx - 1);
        playAudioFeedback('click');
      });
    }
    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        updateTestimonialUI(currentReviewIdx + 1);
        playAudioFeedback('click');
      });
    }
  }

  /* ==========================================================================
     11. MODALS: QUICK VIEW, RECIPES, CERTS, BATCH TRACE, CHECKOUT
     ========================================================================== */
  function openQuickView(productId) {
    const product = PRODUCTS_DATA.find(p => p.id === productId);
    if (!product) return;

    const modal = document.getElementById('quickview-modal');
    const body = document.getElementById('quickview-body');
    if (!modal || !body) return;

    let packSizeButtons = product.packSizes.map((size, idx) => `
      <button class="size-pill-btn ${idx === 1 ? 'active' : ''}" 
              data-size="${size}" 
              onclick="window.UnionFoods.selectQuickViewSize(this, '${size}')">
        ${size}
      </button>
    `).join('');

    let dietaryBadges = product.dietary.map(d => `
      <span style="background: #e8f5e9; color: #2e7d32; font-size: 0.72rem; font-weight: 700; padding: 0.2rem 0.55rem; border-radius: 999px; text-transform: uppercase;">
        ✓ ${d.replace('-', ' ')}
      </span>
    `).join(' ');

    let nutritionRows = Object.entries(product.nutrition).map(([key, val]) => `
      <div style="display: flex; justify-content: space-between; padding: 0.35rem 0; border-bottom: 1px dashed var(--border-light); font-size: 0.85rem;">
        <span style="text-transform: capitalize; color: var(--text-muted);">${key}</span>
        <span style="font-weight: 700; color: var(--text-heading);">${val}</span>
      </div>
    `).join('');

    body.innerHTML = `
      <div style="display: grid; grid-template-columns: 1fr 1.2fr; gap: 2rem; padding: 2rem;">
        <div style="background: var(--bg-warm); border-radius: var(--radius-md); padding: 1.5rem; display: flex; align-items: center; justify-content: center;">
          <img src="${product.image}" alt="${product.name}" style="max-height: 280px; object-fit: contain;">
        </div>
        <div>
          <span style="font-size: 0.78rem; font-weight: 800; color: var(--primary-orange); text-transform: uppercase;">
            ${product.categoryName}
          </span>
          <h2 style="font-size: 1.5rem; font-weight: 800; margin: 0.3rem 0; color: var(--text-heading);">${product.name}</h2>
          <div style="display: flex; align-items: center; gap: 0.5rem; margin-bottom: 0.8rem;">
            <span style="font-size: 1.4rem; font-weight: 900; color: var(--primary-orange);">₹${product.price}</span>
            <span style="font-size: 0.9rem; color: var(--text-light); text-decoration: line-through;">₹${product.originalPrice}</span>
            <span style="background: #dcfce7; color: #166534; font-size: 0.75rem; font-weight: 800; padding: 0.15rem 0.5rem; border-radius: 4px;">Save ₹${product.originalPrice - product.price}</span>
          </div>
          <p style="font-size: 0.88rem; color: var(--text-muted); line-height: 1.6; margin-bottom: 1.2rem;">${product.description}</p>
          
          <div style="margin-bottom: 1rem;">
            <label style="font-size: 0.8rem; font-weight: 700; color: var(--text-heading); display: block; margin-bottom: 0.4rem;">Select Packaging Size:</label>
            <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;" id="qv-size-group">
              ${packSizeButtons}
            </div>
          </div>

          <div style="display: flex; gap: 0.4rem; flex-wrap: wrap; margin-bottom: 1.2rem;">
            ${dietaryBadges}
          </div>

          <div style="background: var(--bg-warm); border-radius: var(--radius-sm); padding: 0.75rem 1rem; margin-bottom: 1.5rem;">
            <div style="font-size: 0.8rem; font-weight: 700; margin-bottom: 0.35rem; color: var(--text-heading);">Nutritional Information (Per 100g)</div>
            ${nutritionRows}
          </div>

          <div style="display: flex; gap: 0.75rem;">
            <button class="btn-primary" style="flex: 1; justify-content: center;" onclick="window.UnionFoods.addFromQuickView('${product.id}')">
              <span>Add to Shopping Cart</span>
            </button>
            <button class="btn-secondary" onclick="window.UnionFoods.toggleWishlist('${product.id}')" title="Wishlist">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
              </svg>
            </button>
          </div>
        </div>
      </div>
    `;

    modal.classList.add('active');
  }

  // Recipe Drawer with Serving Scaler
  let currentRecipeServings = 4;
  function openRecipeModal() {
    const modal = document.getElementById('recipe-modal');
    if (!modal) return;
    renderRecipeDetails(currentRecipeServings);
    modal.classList.add('active');
  }

  function renderRecipeDetails(servings) {
    const container = document.getElementById('recipe-ingredients-list');
    if (!container) return;

    const recipe = RECIPES_DATA.curry;
    const ratio = servings / recipe.servings;

    container.innerHTML = recipe.ingredients.map(ing => {
      const scaledQty = (ing.baseQty * ratio).toFixed(1).replace('.0', '');
      return `
        <li style="display: flex; align-items: center; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid var(--border-light); font-size: 0.9rem;">
          <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
            <input type="checkbox" style="accent-color: var(--primary-orange);">
            <span>${ing.name}</span>
          </label>
          <span style="font-weight: 700; color: var(--primary-orange);">${scaledQty} ${ing.unit}</span>
        </li>
      `;
    }).join('');
  }

  function adjustRecipeServings(delta) {
    currentRecipeServings = Math.max(1, Math.min(12, currentRecipeServings + delta));
    const label = document.getElementById('recipe-servings-val');
    if (label) label.textContent = currentRecipeServings;
    renderRecipeDetails(currentRecipeServings);
    playAudioFeedback('click');
  }

  // Traceability Scanner
  function scanBatchCode(code) {
    const output = document.getElementById('trace-result-box');
    if (!output) return;

    const data = BATCH_TRACES[code.trim().toUpperCase()];
    if (!data) {
      output.innerHTML = `
        <div style="background: #fef2f2; border: 1.5px solid #fecaca; color: #991b1b; padding: 1rem; border-radius: var(--radius-sm); margin-top: 1rem; font-size: 0.88rem;">
          ⚠️ Batch ID <strong>${code}</strong> not found in public ledger. Try sample batches like <code>UF-2026-WHEAT</code> or <code>UF-2026-OIL</code>.
        </div>`;
      return;
    }

    output.innerHTML = `
      <div style="background: #f0fdf4; border: 1.5px solid #bbf7d0; padding: 1.25rem; border-radius: var(--radius-sm); margin-top: 1rem; font-size: 0.88rem;">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 0.6rem;">
          <span style="font-weight: 800; color: #166534; font-size: 1rem;">${data.product}</span>
          <span style="background: #16a34a; color: #fff; font-size: 0.72rem; font-weight: 800; padding: 0.2rem 0.5rem; border-radius: 999px;">${data.status}</span>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.6rem; color: #1f2937;">
          <div>🌾 <strong>Source:</strong> ${data.farmerCoop}</div>
          <div>🏭 <strong>Facility:</strong> ${data.facility}</div>
          <div>📅 <strong>Harvest Date:</strong> ${data.harvestDate}</div>
          <div>⚙️ <strong>Milled & Packed:</strong> ${data.millingDate}</div>
          <div style="grid-column: 1 / -1; margin-top: 0.4rem; padding-top: 0.4rem; border-top: 1px dashed #bbf7d0;">
            🔬 <strong>Lab Analysis:</strong> ${data.labReport} (<strong>${data.purityScore}</strong>)
          </div>
        </div>
      </div>
    `;
    playAudioFeedback('celebrate');
  }

  // Odisha Pincode Delivery Checker
  function checkPincode(pin) {
    const output = document.getElementById('pincode-result-box');
    if (!output) return;

    const trimmed = pin.trim();
    if (!/^\d{6}$/.test(trimmed)) {
      output.innerHTML = `<span style="color: #dc2626; font-size: 0.85rem; font-weight: 600;">Please enter a valid 6-digit Indian PIN code.</span>`;
      return;
    }

    if (trimmed.startsWith('751')) {
      output.innerHTML = `
        <div style="color: #15803d; font-size: 0.85rem; font-weight: 700; margin-top: 0.5rem;">
          🚀 <strong>Bhubaneswar Local Hub!</strong> Express Same-Day & Next-Day delivery available for <strong>${trimmed}</strong>. Free delivery above ₹499.
        </div>`;
    } else if (trimmed.startsWith('75')) {
      output.innerHTML = `
        <div style="color: #15803d; font-size: 0.85rem; font-weight: 700; margin-top: 0.5rem;">
          🚚 <strong>Odisha Statewide Delivery!</strong> Delivery within 24 to 48 hours for <strong>${trimmed}</strong>.
        </div>`;
    } else {
      output.innerHTML = `
        <div style="color: #0284c7; font-size: 0.85rem; font-weight: 700; margin-top: 0.5rem;">
          📦 <strong>Pan-India Shipping!</strong> Standard delivery in 3 to 5 business days for <strong>${trimmed}</strong>.
        </div>`;
    }
    playAudioFeedback('click');
  }

  // Simulated Checkout Flow
  function startCheckout() {
    if (AppState.cart.length === 0) {
      showToast('Your cart is empty! Add items to checkout.', 'error');
      return;
    }

    const { total } = calculateCartTotals();
    const modal = document.getElementById('checkout-modal');
    const summary = document.getElementById('checkout-summary-box');
    if (!modal) return;

    if (summary) {
      summary.innerHTML = `
        <div style="background: var(--bg-warm); padding: 1rem; border-radius: var(--radius-sm); margin-bottom: 1rem;">
          <div style="display: flex; justify-content: space-between; font-weight: 700; margin-bottom: 0.4rem;">
            <span>Items Total (${AppState.cart.length}):</span>
            <span style="color: var(--primary-orange); font-size: 1.15rem;">₹${total}</span>
          </div>
          <p style="font-size: 0.8rem; color: var(--text-muted);">Includes GST, delivery, and active promotional discounts.</p>
        </div>
      `;
    }

    closeCartDrawer();
    modal.classList.add('active');
  }

  function completeOrder(e) {
    if (e) e.preventDefault();
    const orderId = 'UF-' + Math.floor(100000 + Math.random() * 900000);
    const modal = document.getElementById('checkout-modal');
    const orderConfModal = document.getElementById('order-confirmation-modal');

    if (modal) modal.classList.remove('active');

    // Populate order confirmation
    const orderIdEl = document.getElementById('conf-order-id');
    const orderDateEl = document.getElementById('conf-order-date');
    if (orderIdEl) orderIdEl.textContent = orderId;
    if (orderDateEl) orderDateEl.textContent = new Date().toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' });

    // Clear cart
    AppState.cart = [];
    AppState.appliedCoupon = null;
    saveCart();

    if (orderConfModal) {
      orderConfModal.classList.add('active');
    }

    playAudioFeedback('celebrate');
    showToast(`Order #${orderId} Placed Successfully!`, 'success', 5000);
  }

  // FAQ Accordion
  function initFaqAccordion() {
    const items = document.querySelectorAll('.faq-item');
    items.forEach(item => {
      const btn = item.querySelector('.faq-question-btn');
      const ans = item.querySelector('.faq-answer-box');
      if (!btn || !ans) return;

      btn.addEventListener('click', () => {
        const isOpen = item.classList.contains('open');
        items.forEach(i => {
          i.classList.remove('open');
          const a = i.querySelector('.faq-answer-box');
          if (a) a.style.maxHeight = null;
        });

        if (!isOpen) {
          item.classList.add('open');
          ans.style.maxHeight = ans.scrollHeight + 30 + 'px';
        }
        playAudioFeedback('click');
      });
    });
  }

  // Animated Statistics Counter
  function initStatsCounters() {
    const statNums = document.querySelectorAll('.stat-num[data-target]');
    if (!statNums.length) return;

    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const el = entry.target;
          const target = parseInt(el.getAttribute('data-target'), 10);
          const suffix = el.getAttribute('data-suffix') || '';
          let count = 0;
          const step = Math.max(1, Math.floor(target / 40));

          const timer = setInterval(() => {
            count += step;
            if (count >= target) {
              el.textContent = target.toLocaleString() + suffix;
              clearInterval(timer);
            } else {
              el.textContent = count.toLocaleString() + suffix;
            }
          }, 35);

          obs.unobserve(el);
        }
      });
    }, { threshold: 0.4 });

    statNums.forEach(el => observer.observe(el));
  }

  /* ==========================================================================
     12. INITIALIZATION ON DOM READY
     ========================================================================== */
  document.addEventListener('DOMContentLoaded', () => {
    // 1. Navigation & Theme
    initNavigation();
    initThemeAndLanguage();

    // 2. Render initial product catalog
    renderProducts(PRODUCTS_DATA, 'catalog-grid');
    initCategoryFilters();

    // 3. Offers & Testimonials
    initOffersSlider();
    initTestimonialsCarousel();

    // 4. Cart & Wishlist update
    updateCartUI();
    updateWishlistUI();

    // 5. Accordion & Counters
    initFaqAccordion();
    initStatsCounters();

    // 6. Generic Modal Close listeners
    document.querySelectorAll('.modal-overlay').forEach(modal => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal || e.target.closest('.modal-close-btn')) {
          modal.classList.remove('active');
        }
      });
    });

    const cartDrawerOverlay = document.getElementById('cart-drawer-overlay');
    if (cartDrawerOverlay) {
      cartDrawerOverlay.addEventListener('click', closeCartDrawer);
    }

    // 7. Coupon Apply
    const couponForm = document.getElementById('cart-coupon-form');
    if (couponForm) {
      couponForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const codeInput = document.getElementById('cart-coupon-input');
        const code = codeInput ? codeInput.value.trim().toUpperCase() : '';

        if (code === 'UNION10') {
          AppState.appliedCoupon = { code: 'UNION10', type: 'percent', value: 10 };
          showToast('Coupon UNION10 applied! 10% Discount applied.', 'success');
        } else if (code === 'FREESHIP') {
          AppState.appliedCoupon = { code: 'FREESHIP', type: 'shipping', value: 50 };
          showToast('Coupon FREESHIP applied! Free Delivery unlocked.', 'success');
        } else if (code === 'FESTIVE20') {
          AppState.appliedCoupon = { code: 'FESTIVE20', type: 'percent', value: 20 };
          showToast('Coupon FESTIVE20 applied! 20% Discount applied.', 'success');
        } else {
          showToast('Invalid coupon code. Try UNION10 or FREESHIP.', 'error');
        }
        localStorage.setItem('uf_coupon', JSON.stringify(AppState.appliedCoupon));
        updateCartUI();
        playAudioFeedback('click');
      });
    }

    // 8. Newsletter Form
    const newsletterForm = document.getElementById('newsletter-form');
    if (newsletterForm) {
      newsletterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const input = document.getElementById('newsletter-email-input');
        const val = input ? input.value.trim() : '';

        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
          showToast('Please enter a valid email address.', 'error');
          return;
        }

        showToast('🎉 Thank you for subscribing to Union Foods!', 'success', 4500);
        playAudioFeedback('celebrate');
        if (input) input.value = '';
      });
    }

    // 9. Wishlist Global Delegation
    document.addEventListener('click', (e) => {
      const wishBtn = e.target.closest('.wishlist-heart-btn');
      if (wishBtn) {
        e.stopPropagation();
        const pid = wishBtn.getAttribute('data-wishlist-id');
        toggleWishlist(pid);
      }
    });

    // 10. Map Branch Selector
    initMapLocationSelector();

    // 11. Hero Image Slider Controller
    initHeroSlider();

    // 12. Smart Search Listeners
    const navInput = document.getElementById('nav-search-input');
    if (navInput) {
      navInput.addEventListener('input', handleNavSearchInput);
      navInput.addEventListener('keydown', handleNavSearchKeydown);
    }
    const navClear = document.getElementById('nav-search-clear-btn');
    if (navClear) {
      navClear.addEventListener('click', () => {
        if (navInput) {
          navInput.value = '';
          navInput.focus();
        }
        navClear.style.display = 'none';
        const box = document.getElementById('nav-search-suggestions');
        if (box) box.style.display = 'none';
      });
    }

    // Modal Search input listeners
    const modalInput = document.getElementById('modal-search-input');
    const modalClear = document.getElementById('modal-search-clear');
    if (modalInput) {
      modalInput.addEventListener('input', (e) => {
        const val = e.target.value;
        if (modalClear) modalClear.style.display = val ? 'flex' : 'none';
        renderSearchResults(val);
      });
      modalInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          saveSearchQuery(modalInput.value);
        } else if (e.key === 'Escape') {
          closeSearchModal();
        }
      });
    }
    if (modalClear) {
      modalClear.addEventListener('click', () => {
        if (modalInput) {
          modalInput.value = '';
          modalInput.focus();
        }
        modalClear.style.display = 'none';
        renderSearchResults('');
      });
    }

    // Filter pills click
    document.querySelectorAll('.search-filter-pill').forEach(pill => {
      pill.addEventListener('click', () => {
        document.querySelectorAll('.search-filter-pill').forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        currentSearchFilter = pill.getAttribute('data-filter') || 'all';
        renderSearchResults(modalInput ? modalInput.value : '');
      });
    });

    // Close suggestions on outside click
    document.addEventListener('click', (e) => {
      const wrap = document.getElementById('header-search-wrap');
      const box = document.getElementById('nav-search-suggestions');
      if (box && wrap && !wrap.contains(e.target)) {
        box.style.display = 'none';
      }
    });

    // Global Esc key closes search modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        closeSearchModal();
      }
    });
  });

  /* ==========================================================================
     13. MAP LOCATIONS & INTERACTIVE PREVIEW CONTROLLER
     ========================================================================== */
  const MAP_LOCATIONS = {
    chandaka: {
      name: 'Union Foods Headquarters & Main Plant',
      type: 'Corporate HQ & Processing Plant',
      address: 'Plot No. 14, Chandaka Industrial Estate, Patia, Bhubaneswar, Odisha - 751024',
      timing: 'Mon - Sat: 9:00 AM - 7:00 PM (Closed Sundays)',
      phone: '+91 98765 43210',
      email: 'info@unionfoods.in',
      distance: 'Central Hub • 2.4 km from Infocity',
      status: 'Open Now • Closes at 7:00 PM',
      embedUrl: 'https://maps.google.com/maps?q=Chandaka+Industrial+Area+Patia+Bhubaneswar+Odisha+India&t=&z=14&ie=UTF8&iwloc=&output=embed',
      directUrl: 'https://www.google.com/maps/search/?api=1&query=Chandaka+Industrial+Estate+Patia+Bhubaneswar+Odisha',
      tags: ['Main Processing Plant', 'Contactless Packaging', 'Quality QA Lab', 'Visitor Parking', 'B2B Wholesale Desk']
    },
    mancheswar: {
      name: 'Central Grain Milling & Sortex Unit',
      type: 'Industrial Milling & Logistics Hub',
      address: 'Sector A, Mancheswar Industrial Estate, Rasulgarh, Bhubaneswar, Odisha - 751010',
      timing: 'Mon - Sat: 8:00 AM - 8:00 PM',
      phone: '+91 98765 43211',
      email: 'milling@unionfoods.in',
      distance: 'Industrial Zone • 3.1 km from Rasulgarh Square',
      status: 'Open Now • Closes at 8:00 PM',
      embedUrl: 'https://maps.google.com/maps?q=Mancheswar+Industrial+Estate+Rasulgarh+Bhubaneswar+Odisha+India&t=&z=14&ie=UTF8&iwloc=&output=embed',
      directUrl: 'https://www.google.com/maps/search/?api=1&query=Mancheswar+Industrial+Estate+Bhubaneswar+Odisha',
      tags: ['Optical Sortex Cleaning', 'Chakki Fresh Atta Mill', 'High Capacity Silos', 'Heavy Vehicle Loading']
    },
    saheed_nagar: {
      name: 'Retail Experience & Sampling Center',
      type: 'Flagship Store & Experience Lounge',
      address: 'Janpath Boulevard, Near Vani Vihar, Saheed Nagar, Bhubaneswar, Odisha - 751007',
      timing: 'Open All 7 Days: 9:30 AM - 9:30 PM',
      phone: '+91 98765 43212',
      email: 'experience@unionfoods.in',
      distance: 'City Center • 500m from Saheed Nagar Metro Pillar',
      status: 'Open Now • Closes at 9:30 PM',
      embedUrl: 'https://maps.google.com/maps?q=Saheed+Nagar+Janpath+Bhubaneswar+Odisha+India&t=&z=15&ie=UTF8&iwloc=&output=embed',
      directUrl: 'https://www.google.com/maps/search/?api=1&query=Saheed+Nagar+Janpath+Bhubaneswar+Odisha',
      tags: ['Direct Consumer Store', 'Live Cold-Press Demo', 'Recipe Tasting Bar', 'Instant Pickup Desk']
    },
    cuttack: {
      name: 'Twin City Distribution & Storage Depot',
      type: 'Statewide Dispatch Depot',
      address: 'Madhupatna Industrial Area, Link Road, Cuttack, Odisha - 753010',
      timing: 'Mon - Sat: 9:00 AM - 6:30 PM',
      phone: '+91 98765 43213',
      email: 'cuttack.hub@unionfoods.in',
      distance: 'Twin City Link • Near OMP Square Cuttack',
      status: 'Open Now • Closes at 6:30 PM',
      embedUrl: 'https://maps.google.com/maps?q=Madhupatna+Cuttack+Odisha+India&t=&z=14&ie=UTF8&iwloc=&output=embed',
      directUrl: 'https://www.google.com/maps/search/?api=1&query=Madhupatna+Cuttack+Odisha',
      tags: ['Express Fleet Depot', 'Temperature Controlled Cold Store', 'Distributor Desk']
    }
  };

  let currentMapKey = 'chandaka';
  let currentMapMode = 'm'; // m: map, k: satellite

  function switchMapLocation(key) {
    const loc = MAP_LOCATIONS[key];
    if (!loc) return;
    currentMapKey = key;

    // Update Tab active classes
    document.querySelectorAll('.map-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-location-key') === key);
    });

    // Update Info Card
    const titleEl = document.getElementById('map-loc-name');
    const typeEl = document.getElementById('map-loc-type');
    const addrEl = document.getElementById('map-loc-address');
    const hoursEl = document.getElementById('map-loc-hours');
    const phoneEl = document.getElementById('map-loc-phone');
    const emailEl = document.getElementById('map-loc-email');
    const tagsEl = document.getElementById('map-loc-tags');
    const dirBtn = document.getElementById('map-directions-btn');
    const pinName = document.getElementById('map-floating-pin-name');
    const iframe = document.getElementById('map-iframe');

    if (titleEl) titleEl.textContent = loc.name;
    if (typeEl) typeEl.textContent = loc.type;
    if (addrEl) addrEl.textContent = loc.address;
    if (hoursEl) hoursEl.textContent = loc.timing;
    if (phoneEl) {
      phoneEl.textContent = loc.phone;
      phoneEl.setAttribute('href', `tel:${loc.phone.replace(/\s+/g, '')}`);
    }
    if (emailEl) {
      emailEl.textContent = loc.email;
      emailEl.setAttribute('href', `mailto:${loc.email}`);
    }
    if (tagsEl) {
      tagsEl.innerHTML = loc.tags.map(t => `<span class="map-tag">${t}</span>`).join('');
    }
    if (dirBtn) {
      dirBtn.setAttribute('href', loc.directUrl);
    }
    if (pinName) {
      pinName.textContent = loc.name;
    }
    if (iframe) {
      let finalUrl = loc.embedUrl;
      if (currentMapMode === 'k') {
        finalUrl += '&t=k';
      }
      iframe.src = finalUrl;
    }

    playAudioFeedback('click');
    showToast(`Switched map preview to ${loc.name}`, 'info');
  }

  function setMapViewMode(mode) {
    currentMapMode = mode;
    document.querySelectorAll('.map-ctrl-btn[data-mode]').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-mode') === mode);
    });
    const iframe = document.getElementById('map-iframe');
    const loc = MAP_LOCATIONS[currentMapKey];
    if (iframe && loc) {
      iframe.src = loc.embedUrl + (mode === 'k' ? '&t=k' : '');
    }
    playAudioFeedback('click');
  }

  function initMapLocationSelector() {
    document.querySelectorAll('.map-tab-btn[data-location-key]').forEach(btn => {
      btn.addEventListener('click', () => {
        const key = btn.getAttribute('data-location-key');
        switchMapLocation(key);
      });
    });

    document.querySelectorAll('.map-ctrl-btn[data-mode]').forEach(btn => {
      btn.addEventListener('click', () => {
        const mode = btn.getAttribute('data-mode');
        setMapViewMode(mode);
      });
    });
  }

  /* ==========================================================================
     14. EXPOSE GLOBAL APIS FOR INLINE HTML EVENT HANDLERS
     ========================================================================== */

  /* ==========================================================================
     SMART SEARCH ENGINE KNOWLEDGE BASE (18 Comprehensive Content Domains)
     ========================================================================== */
  const SEARCH_DATABASE = [
    // 1. Products - Cooking Oils
    {
      id: 'search-oil-1',
      name: 'Refined Sunflower Oil (1L & 5L)',
      category: 'Cooking Oil',
      type: 'product',
      price: 145,
      priceDisplay: '₹145',
      image: 'assets/images/prod-oil.jpg',
      description: 'Triple refined, 100% pure sunflower oil enriched with Vitamins A & D. Light, healthy, and cholesterol-free for everyday family cooking.',
      keywords: ['oil', 'sunflower', 'cooking oil', 'refined oil', 'heart healthy', 'fry', 'kitchen staples'],
      url: '#products-section',
      actionId: 'uf-oil-1'
    },
    {
      id: 'search-oil-2',
      name: 'Kachi Ghani Mustard Oil (1L)',
      category: 'Cooking Oil',
      type: 'product',
      price: 155,
      priceDisplay: '₹155',
      image: 'assets/images/prod-oil.jpg',
      description: 'Cold-pressed traditional mustard oil with strong pungency and natural antioxidants. Ideal for authentic pickles and pungent curries.',
      keywords: ['oil', 'mustard oil', 'kachi ghani', 'sarson tel', 'pungent', 'pickles', 'traditional'],
      url: '#products-section',
      actionId: 'uf-mustard-1'
    },

    // 2. Products - Flour & Grains
    {
      id: 'search-atta-1',
      name: 'Premium Sharbati Atta (5Kg & 10Kg)',
      category: 'Flour & Grains',
      type: 'product',
      price: 245,
      priceDisplay: '₹245',
      image: 'assets/images/prod-atta.jpg',
      description: '100% whole wheat chakki fresh flour milled from golden Sharbati grains. Makes rotis that stay soft, fluffy, and aromatic for hours.',
      keywords: ['atta', 'wheat', 'flour', 'sharbati', 'chakki fresh', 'roti', 'chapati', 'whole wheat', 'grains'],
      url: '#products-section',
      actionId: 'uf-atta-1'
    },

    // 3. Products - Pulses & Dal
    {
      id: 'search-dal-1',
      name: 'Unpolished Moong Dal (1Kg)',
      category: 'Pulses & Dal',
      type: 'product',
      price: 135,
      priceDisplay: '₹135',
      image: 'assets/images/prod-dal.jpg',
      description: 'Premium unpolished yellow moong lentils with natural nutrients and wholesome flavor intact. Easy to digest and rich in plant protein.',
      keywords: ['dal', 'moong dal', 'pulses', 'lentils', 'yellow dal', 'protein', 'unpolished'],
      url: '#products-section',
      actionId: 'uf-moong-1'
    },
    {
      id: 'search-dal-2',
      name: 'Desi Chana Dal (1Kg)',
      category: 'Pulses & Dal',
      type: 'product',
      price: 115,
      priceDisplay: '₹115',
      image: 'assets/images/prod-dal.jpg',
      description: 'Golden, nutritious bengal gram split lentils carefully sorted and packed. Rich in dietary fiber, low glycemic index, and zinc.',
      keywords: ['dal', 'chana dal', 'pulses', 'bengal gram', 'tadka', 'fiber', 'desi'],
      url: '#products-section',
      actionId: 'uf-chana-1'
    },
    {
      id: 'search-dal-3',
      name: 'Premium Toor Dal (1Kg)',
      category: 'Pulses & Dal',
      type: 'product',
      price: 165,
      priceDisplay: '₹165',
      image: 'assets/images/prod-dal.jpg',
      description: 'High-protein unpolished pigeon pea lentils for daily wholesome dal tadka, sambar, and Gujarati dal.',
      keywords: ['dal', 'toor dal', 'arhar dal', 'pulses', 'sambar', 'protein'],
      url: '#products-section',
      actionId: 'uf-toor-1'
    },

    // 4. Products - Spices
    {
      id: 'search-spice-1',
      name: 'Pure Turmeric Powder (Haldi 500g)',
      category: 'Spices',
      type: 'product',
      price: 95,
      priceDisplay: '₹95',
      image: 'assets/images/prod-spices.jpg',
      description: 'High-curcumin aromatic turmeric ground from select Kandhamal farm roots with zero added artificial colors or preservatives.',
      keywords: ['spices', 'haldi', 'turmeric', 'curcumin', 'kandhamal', 'pure masala', 'yellow'],
      url: '#products-section',
      actionId: 'uf-haldi-1'
    },

    // 5. Products - Snacks
    {
      id: 'search-snack-1',
      name: 'Traditional Odisha Mixture & Namkeen',
      category: 'Snacks',
      type: 'product',
      price: 85,
      priceDisplay: '₹85',
      image: 'assets/images/cat-snacks.jpg',
      description: 'Crunchy savory tea-time mixture fried in pure Union Foods sunflower oil with curry leaves, peanuts, and authentic spices.',
      keywords: ['snacks', 'namkeen', 'mixture', 'tea time', 'crunchy', 'munchies'],
      url: '#categories-section',
      actionId: 'cat-snacks'
    },

    // 6. Products - Beverages
    {
      id: 'search-bev-1',
      name: 'Fresh Kesar Mango Lassi & Juices',
      category: 'Beverages',
      type: 'product',
      price: 60,
      priceDisplay: '₹60',
      image: 'assets/images/food-lassi.jpg',
      description: 'Refreshing probiotic curd smoothie blended with sweet mango pulp, saffron strands, and natural cardamom.',
      keywords: ['beverages', 'lassi', 'mango', 'juice', 'kesar', 'drink', 'refreshing'],
      url: '#categories-section',
      actionId: 'cat-beverages'
    },

    // 7. Product Categories (6 Categories)
    {
      id: 'search-cat-oil',
      name: 'Cooking Oils Category',
      category: 'Categories',
      type: 'category',
      price: 0,
      priceDisplay: 'From ₹145',
      image: 'assets/images/cat-oil.jpg',
      description: 'Explore our range of heart-healthy refined sunflower oil, kachi ghani mustard oil, and cold-pressed oils.',
      keywords: ['category', 'cooking oil', 'oil', 'mustard', 'sunflower'],
      url: '#categories-section',
      actionId: 'oil'
    },
    {
      id: 'search-cat-flour',
      name: 'Flour & Grains Category',
      category: 'Categories',
      type: 'category',
      price: 0,
      priceDisplay: 'From ₹48/kg',
      image: 'assets/images/cat-flour.jpg',
      description: '100% natural Chakki fresh Sharbati whole wheat atta, multigrain atta, and nutrient-dense grain flours.',
      keywords: ['category', 'flour', 'grains', 'atta', 'wheat', 'sharbati'],
      url: '#categories-section',
      actionId: 'flour'
    },
    {
      id: 'search-cat-pulses',
      name: 'Pulses & Dal Category',
      category: 'Categories',
      type: 'category',
      price: 0,
      priceDisplay: 'From ₹115',
      image: 'assets/images/cat-pulses.jpg',
      description: 'Unpolished, naturally grown moong dal, toor dal, and desi chana dal packed with wholesome plant protein.',
      keywords: ['category', 'pulses', 'dal', 'lentils', 'moong', 'toor', 'chana'],
      url: '#categories-section',
      actionId: 'pulses'
    },
    {
      id: 'search-cat-spices',
      name: 'Pure Spices Category',
      category: 'Categories',
      type: 'category',
      price: 0,
      priceDisplay: 'From ₹45',
      image: 'assets/images/cat-spices.jpg',
      description: 'Sun-dried, high-aroma whole and powdered spices including Haldi, Dhaniya, Jeera, and Mirch.',
      keywords: ['category', 'spices', 'haldi', 'turmeric', 'chili', 'masala'],
      url: '#categories-section',
      actionId: 'spices'
    },
    {
      id: 'search-cat-snacks',
      name: 'Healthy Snacks Category',
      category: 'Categories',
      type: 'category',
      price: 0,
      priceDisplay: 'From ₹40',
      image: 'assets/images/cat-snacks.jpg',
      description: 'Crispy namkeens, roasted nuts, and wholesome tea-time snacks prepared hygienically in pure vegetable oil.',
      keywords: ['category', 'snacks', 'namkeen', 'healthy snacks'],
      url: '#categories-section',
      actionId: 'snacks'
    },
    {
      id: 'search-cat-beverages',
      name: 'Pure Beverages Category',
      category: 'Categories',
      type: 'category',
      price: 0,
      priceDisplay: 'From ₹35',
      image: 'assets/images/cat-beverages.jpg',
      description: 'Chilled natural lassi, probiotic yogurt drinks, and fresh wholesome fruit juices.',
      keywords: ['category', 'beverages', 'drinks', 'lassi', 'juice'],
      url: '#categories-section',
      actionId: 'beverages'
    },

    // 8. Special Food Offers & Discounts
    {
      id: 'search-offer-1',
      name: 'Buy 1 Get 1 Free: Premium Moong Dal',
      category: 'Offers & Deals',
      type: 'offer',
      price: 135,
      priceDisplay: 'BOGO FREE',
      image: 'assets/images/prod-dal.jpg',
      description: 'Special limited time deal: Buy one unpolished yellow moong dal pack and get another pack free! Coupon: BOGO-MOONG',
      keywords: ['offer', 'discount', 'bogo', 'buy 1 get 1', 'free', 'deals', 'special offers', 'coupon'],
      url: '#offers-slider-section',
      actionId: 'uf-moong-1'
    },
    {
      id: 'search-offer-2',
      name: 'Flat 20% OFF: Refined Sunflower Oil 5L',
      category: 'Offers & Deals',
      type: 'offer',
      price: 680,
      priceDisplay: '20% OFF',
      image: 'assets/images/prod-oil.jpg',
      description: 'Save 20% on our family economy sunflower oil 5L jar. Use coupon code SUN20 during checkout.',
      keywords: ['offer', 'discount', '20% off', 'deals', 'sunflower oil', 'coupon', 'savings'],
      url: '#offers-slider-section',
      actionId: 'uf-oil-1'
    },
    {
      id: 'search-offer-3',
      name: 'Family Essentials Combo: Flat 30% OFF',
      category: 'Offers & Deals',
      type: 'offer',
      price: 499,
      priceDisplay: '30% OFF',
      image: 'assets/images/banner-4-pantry.jpg',
      description: 'Sharbati Atta 5kg + Sunflower Oil 1L + Moong Dal 1kg at an unbeatable combo bundle price. Code: UNION30',
      keywords: ['offer', 'discount', 'combo', 'bundle', '30% off', 'family pack', 'deals'],
      url: '#offers-slider-section',
      actionId: 'uf-atta-1'
    },
    {
      id: 'search-offer-4',
      name: 'Free Express Delivery Across Odisha',
      category: 'Offers & Deals',
      type: 'offer',
      price: 0,
      priceDisplay: 'FREE SHIP',
      image: 'assets/images/cert-fssai.svg',
      description: 'Zero delivery fee on all groceries and pantry orders above ₹499 in Bhubaneswar, Cuttack, and Odisha.',
      keywords: ['free delivery', 'free shipping', 'zero delivery fee', 'express delivery', 'deals'],
      url: '#cart-drawer',
      actionId: 'cart'
    },

    // 9. Recipes
    {
      id: 'search-recipe-paneer',
      name: 'Shahi Paneer Masala Recipe',
      category: 'Recipes',
      type: 'recipe',
      price: 0,
      priceDisplay: 'Recipe Card',
      image: 'assets/images/food-paneer.jpg',
      description: 'Rich, royal cottage cheese curry simmered in a velvety gravy of cashews, tomatoes, and pure Union Foods spices.',
      keywords: ['recipe', 'paneer', 'shahi paneer', 'cooking', 'curry', 'dinner', 'lunch'],
      url: '#recipes',
      actionId: 'shahi-paneer'
    },
    {
      id: 'search-recipe-biryani',
      name: 'Vegetable Dum Biryani Recipe',
      category: 'Recipes',
      type: 'recipe',
      price: 0,
      priceDisplay: 'Recipe Card',
      image: 'assets/images/food-biryani.jpg',
      description: 'Aromatic layered basmati rice with farm vegetables, saffron, and slow-cooked sealed dum perfection.',
      keywords: ['recipe', 'biryani', 'dum biryani', 'rice', 'pulao', 'cooking'],
      url: '#recipes',
      actionId: 'biryani'
    },
    {
      id: 'search-recipe-dosa',
      name: 'Crispy Masala Dosa Recipe',
      category: 'Recipes',
      type: 'recipe',
      price: 0,
      priceDisplay: 'Recipe Card',
      image: 'assets/images/food-dosa.jpg',
      description: 'Golden fermented rice-urad crepe with spiced potato filling, coconut chutney, and piping hot sambar.',
      keywords: ['recipe', 'dosa', 'masala dosa', 'south indian', 'breakfast', 'crispy'],
      url: '#recipes',
      actionId: 'dosa'
    },
    {
      id: 'search-recipe-samosa',
      name: 'Golden Desi Samosas Recipe',
      category: 'Recipes',
      type: 'recipe',
      price: 0,
      priceDisplay: 'Recipe Card',
      image: 'assets/images/food-samosa.jpg',
      description: 'Flaky pastry triangles filled with spiced cumin potatoes and green peas, deep-fried in Union Foods sunflower oil.',
      keywords: ['recipe', 'samosa', 'snacks', 'evening snack', 'fried'],
      url: '#recipes',
      actionId: 'samosa'
    },
    {
      id: 'search-recipe-puri',
      name: 'Crispy Puri & Aloo Dum Recipe',
      category: 'Recipes',
      type: 'recipe',
      price: 0,
      priceDisplay: 'Recipe Card',
      image: 'assets/images/food-puri-sabji.jpg',
      description: 'Puffy whole wheat puris made with Sharbati atta paired with spicy baby potato dum curry.',
      keywords: ['recipe', 'puri', 'aloo dum', 'breakfast favorite', 'atta'],
      url: '#recipes',
      actionId: 'puri-sabji'
    },

    // 10. Company Information & About Us
    {
      id: 'search-info-about',
      name: 'About Union Foods - Est. 1982',
      category: 'Company Info',
      type: 'info',
      price: 0,
      priceDisplay: '40+ Years',
      image: 'assets/images/union-foods-logo.png',
      description: 'Founded in 1982, Union Foods has grown into Odisha’s premier food brand delivering pure, wholesome staples to over 500,000 households.',
      keywords: ['about', 'about us', 'company', 'union foods', 'history', 'founder', 'heritage', 'est 1982', 'odisha'],
      url: '#about',
      actionId: 'about'
    },
    {
      id: 'search-info-mission',
      name: 'Our Farm-to-Table Quality Promise',
      category: 'Company Info',
      type: 'info',
      price: 0,
      priceDisplay: 'Our Values',
      image: 'assets/images/banner-2-farmer.jpg',
      description: 'Direct procurement from trusted Indian farmers with zero middlemen, fair prices, and rigorous 7-stage quality inspection.',
      keywords: ['mission', 'values', 'quality', 'farmer', 'sustainability', 'purity'],
      url: '#why-choose',
      actionId: 'why-choose'
    },
    {
      id: 'search-info-contact',
      name: 'Contact & Customer Support',
      category: 'Company Info',
      type: 'info',
      price: 0,
      priceDisplay: '+91 98765 43210',
      image: 'assets/images/union-foods-logo.png',
      description: 'Phone: +91 98765 43210 | Email: info@unionfoods.in | Corporate HQ: Plot 42, Infocity Road, Patia, Bhubaneswar, Odisha.',
      keywords: ['contact', 'phone', 'email', 'support', 'help', 'address', 'office', 'headquarters', 'bhubaneswar'],
      url: '#contact',
      actionId: 'contact'
    },

    // 11. Certifications
    {
      id: 'search-cert-fssai',
      name: 'FSSAI License No: 10019031003214',
      category: 'Certifications',
      type: 'certification',
      price: 0,
      priceDisplay: 'Government Certified',
      image: 'assets/images/cert-fssai.svg',
      description: 'Official Food Safety and Standards Authority of India (FSSAI) license guaranteeing statutory compliance, unadulterated purity, and safety.',
      keywords: ['certification', 'fssai', 'license', 'quality', 'safety', 'government', 'standards'],
      url: '#certifications-section',
      actionId: 'fssai'
    },
    {
      id: 'search-cert-iso',
      name: 'ISO 22000 Food Safety Management',
      category: 'Certifications',
      type: 'certification',
      price: 0,
      priceDisplay: 'Global Standard',
      image: 'assets/images/cert-iso.svg',
      description: 'Internationally recognized certification for comprehensive food hygiene, traceability, and hazard management across the supply chain.',
      keywords: ['certification', 'iso', 'iso 22000', 'global', 'hygiene'],
      url: '#certifications-section',
      actionId: 'iso'
    },
    {
      id: 'search-cert-haccp',
      name: 'HACCP Hazard Control Certified',
      category: 'Certifications',
      type: 'certification',
      price: 0,
      priceDisplay: 'Zero Defect',
      image: 'assets/images/cert-haccp.svg',
      description: 'Rigorous Hazard Analysis Critical Control Point system applied across all automated milling, extraction, and sealing lines.',
      keywords: ['certification', 'haccp', 'hazard', 'safety', 'clean'],
      url: '#certifications-section',
      actionId: 'haccp'
    },

    // 12. Locations & Hubs
    {
      id: 'search-loc-bhubaneswar',
      name: 'Bhubaneswar Central Processing & Express Hub',
      category: 'Company Info',
      type: 'info',
      price: 0,
      priceDisplay: 'Hub 1',
      image: 'assets/images/facility.svg',
      description: 'Plot 42, Infocity Road, Patia, Bhubaneswar. 45,000 sq.ft state-of-the-art automated flour mill and oil packaging unit with live preview.',
      keywords: ['locations', 'bhubaneswar', 'patia', 'hub', 'processing plant', 'facility', 'map'],
      url: '#locations',
      actionId: 'bhubaneswar'
    },
    {
      id: 'search-loc-cuttack',
      name: 'Cuttack Metro Distribution Depot',
      category: 'Company Info',
      type: 'info',
      price: 0,
      priceDisplay: 'Hub 2',
      image: 'assets/images/facility.svg',
      description: 'Malgodown Commercial Zone, Cuttack. High-volume transit center catering to twin city wholesale networks and fast home delivery.',
      keywords: ['locations', 'cuttack', 'malgodown', 'depot', 'distribution'],
      url: '#locations',
      actionId: 'cuttack'
    }
  ];

  window.searchData = SEARCH_DATABASE;

  /* ==========================================================================
     SMART SEARCH LOGIC & CONTROLLER
     ========================================================================== */
  let currentSearchFilter = 'all';
  let currentSearchSort = 'relevance';
  let searchHistory = [];

  try {
    const saved = localStorage.getItem('union_search_history');
    if (saved) searchHistory = JSON.parse(saved);
  } catch (e) {
    searchHistory = ['Mustard Oil', 'Sharbati Atta', 'BOGO Offer'];
  }

  function saveSearchQuery(query) {
    if (!query || query.trim().length < 2) return;
    query = query.trim();
    searchHistory = [query, ...searchHistory.filter(q => q.toLowerCase() !== query.toLowerCase())].slice(0, 8);
    try {
      localStorage.setItem('union_search_history', JSON.stringify(searchHistory));
    } catch (e) {}
    renderSearchHistoryChips();
  }

  function clearSearchHistory() {
    searchHistory = [];
    try {
      localStorage.removeItem('union_search_history');
    } catch (e) {}
    renderSearchHistoryChips();
  }

  function removeHistoryItem(term) {
    searchHistory = searchHistory.filter(t => t.toLowerCase() !== term.toLowerCase());
    try {
      localStorage.setItem('union_search_history', JSON.stringify(searchHistory));
    } catch (e) {}
    renderSearchHistoryChips();
  }

  function renderSearchHistoryChips() {
    const block = document.getElementById('recent-searches-block');
    const container = document.getElementById('recent-chips-container');
    if (!block || !container) return;

    if (searchHistory.length === 0) {
      block.style.display = 'none';
      return;
    }

    block.style.display = 'block';
    container.innerHTML = searchHistory.map(term => `
      <span class="search-chip">
        <span onclick="window.UnionFoods.applySearchChip('${term.replace(/'/g, "\\'")}')">${term}</span>
        <button type="button" class="chip-remove-btn" onclick="window.UnionFoods.removeHistoryItem('${term.replace(/'/g, "\\'")}')" aria-label="Remove ${term}">&times;</button>
      </span>
    `).join('');
  }

  function highlightMatches(text, query) {
    if (!query || !text) return text;
    const tokens = query.toLowerCase().split(/\s+/).filter(Boolean);
    if (!tokens.length) return text;
    const regex = new RegExp(`(${tokens.map(t => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})`, 'gi');
    return text.replace(regex, '<mark class="search-highlight">$1</mark>');
  }

  function executeSearch(query) {
    query = (query || '').trim().toLowerCase();
    const tokens = query.split(/\s+/).filter(Boolean);

    let results = SEARCH_DATABASE.map(item => {
      let score = 0;
      if (!tokens.length) {
        // Return default recommendation score based on popularity
        score = item.type === 'product' ? 10 : (item.type === 'offer' ? 9 : 5);
        return { item, score };
      }

      const nameLower = item.name.toLowerCase();
      const catLower = item.category.toLowerCase();
      const descLower = item.description.toLowerCase();
      const kwString = (item.keywords || []).join(' ').toLowerCase();

      // Exact name match
      if (nameLower === query) score += 100;
      else if (nameLower.startsWith(query)) score += 60;
      else if (nameLower.includes(query)) score += 40;

      // Token matching
      tokens.forEach(tok => {
        if (nameLower.includes(tok)) score += 25;
        if (catLower.includes(tok)) score += 20;
        if (kwString.includes(tok)) score += 18;
        if (descLower.includes(tok)) score += 10;
      });

      return { item, score };
    });

    results = results.filter(r => r.score > 0);

    // Apply Filter
    if (currentSearchFilter !== 'all') {
      results = results.filter(r => r.item.type === currentSearchFilter);
    }

    // Apply Sorting
    if (currentSearchSort === 'price-asc') {
      results.sort((a, b) => a.item.price - b.item.price);
    } else if (currentSearchSort === 'price-desc') {
      results.sort((a, b) => b.item.price - a.item.price);
    } else if (currentSearchSort === 'name-asc') {
      results.sort((a, b) => a.item.name.localeCompare(b.item.name));
    } else {
      // Relevance
      results.sort((a, b) => b.score - a.score);
    }

    return results.map(r => r.item);
  }

  function updateFilterCounts(query) {
    const counts = { all: 0, product: 0, category: 0, offer: 0, recipe: 0, info: 0, certification: 0 };
    const q = (query || '').trim().toLowerCase();
    const tokens = q.split(/\s+/).filter(Boolean);

    SEARCH_DATABASE.forEach(item => {
      let matches = true;
      if (tokens.length) {
        const text = (item.name + ' ' + item.category + ' ' + item.description + ' ' + (item.keywords || []).join(' ')).toLowerCase();
        matches = tokens.some(t => text.includes(t));
      }
      if (matches) {
        counts.all++;
        if (counts[item.type] !== undefined) counts[item.type]++;
      }
    });

    ['all', 'product', 'category', 'offer', 'recipe', 'info', 'certification'].forEach(t => {
      const el = document.getElementById(`count-${t}`);
      if (el) el.textContent = counts[t] || 0;
    });
  }

  function renderSearchResults(query) {
    const grid = document.getElementById('search-results-grid');
    const noResults = document.getElementById('search-no-results');
    const defaultsBox = document.getElementById('search-defaults-box');
    const statusText = document.getElementById('search-status-text');
    if (!grid) return;

    updateFilterCounts(query);
    const results = executeSearch(query);

    if (results.length === 0) {
      grid.innerHTML = '';
      if (noResults) noResults.style.display = 'block';
      if (defaultsBox) defaultsBox.style.display = 'none';
      if (statusText) statusText.textContent = `No matches found for "${query}"`;
      return;
    }

    if (noResults) noResults.style.display = 'none';
    if (defaultsBox) defaultsBox.style.display = query ? 'none' : 'block';
    if (statusText) {
      statusText.textContent = query
        ? `Found ${results.length} result${results.length === 1 ? '' : 's'} for "${query}"`
        : `Showing ${results.length} recommended items`;
    }

    grid.innerHTML = results.map(item => {
      const highlightedName = highlightMatches(item.name, query);
      const highlightedDesc = highlightMatches(item.description, query);
      const actionText = item.type === 'product' ? 'View & Buy' : (item.type === 'recipe' ? 'View Recipe' : (item.type === 'offer' ? 'Claim Deal' : 'Navigate &rarr;'));

      return `
        <div class="search-result-card" onclick="window.UnionFoods.handleResultClick('${item.id}')">
          <div class="search-card-thumb-wrap">
            <span class="search-card-badge">${item.category}</span>
            <img src="${item.image}" alt="${item.name}" class="search-card-thumb" loading="lazy">
          </div>
          <h4 class="search-card-title">${highlightedName}</h4>
          <p class="search-card-desc">${highlightedDesc}</p>
          <div class="search-card-footer">
            <span class="search-card-price">${item.priceDisplay}</span>
            <button type="button" class="search-card-action-btn">${actionText}</button>
          </div>
        </div>
      `;
    }).join('');
  }

  function handleResultClick(itemId) {
    const item = SEARCH_DATABASE.find(i => i.id === itemId);
    if (!item) return;

    closeSearchModal();

    if (item.type === 'product' && item.actionId) {
      openQuickView(item.actionId);
    } else if (item.type === 'recipe') {
      openRecipeModal(item.actionId);
    } else if (item.type === 'category') {
      filterCategory(item.actionId);
      const target = document.querySelector(item.url);
      if (target) target.scrollIntoView({ behavior: 'smooth' });
    } else {
      const target = document.querySelector(item.url);
      if (target) target.scrollIntoView({ behavior: 'smooth' });
    }
  }

  function openSearchModal(initialQuery = '', filter = 'all') {
    const modal = document.getElementById('search-modal');
    const input = document.getElementById('modal-search-input');
    if (!modal) return;

    currentSearchFilter = filter;
    document.querySelectorAll('.search-filter-pill').forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-filter') === filter);
    });

    modal.classList.add('active');
    renderSearchHistoryChips();

    if (input) {
      input.value = initialQuery;
      const clearBtn = document.getElementById('modal-search-clear');
      if (clearBtn) clearBtn.style.display = initialQuery ? 'flex' : 'none';
      setTimeout(() => input.focus(), 150);
    }

    renderSearchResults(initialQuery);
  }

  function closeSearchModal() {
    const modal = document.getElementById('search-modal');
    if (modal) modal.classList.remove('active');
  }

  /* Live Autocomplete in Navbar */
  let activeSuggestionIndex = -1;

  function handleNavSearchInput(e) {
    const query = e.target.value.trim();
    const clearBtn = document.getElementById('nav-search-clear-btn');
    const box = document.getElementById('nav-search-suggestions');
    const list = document.getElementById('suggestions-list-box');
    if (clearBtn) clearBtn.style.display = query ? 'flex' : 'none';

    if (!query || query.length < 1) {
      if (box) box.style.display = 'none';
      return;
    }

    const matches = executeSearch(query).slice(0, 6);
    if (!matches.length) {
      if (box) box.style.display = 'none';
      return;
    }

    activeSuggestionIndex = -1;
    if (list) {
      list.innerHTML = matches.map((item, idx) => `
        <div class="suggestion-item" data-index="${idx}" onclick="window.UnionFoods.handleSuggestionClick('${item.id}')">
          <div class="suggestion-item-main">
            <img src="${item.image}" alt="${item.name}" class="suggestion-thumb">
            <div>
              <div class="suggestion-title">${highlightMatches(item.name, query)}</div>
              <small style="color: var(--text-muted); font-size: 0.75rem;">${item.category}</small>
            </div>
          </div>
          <span class="suggestion-tag">${item.priceDisplay}</span>
        </div>
      `).join('');
    }

    if (box) box.style.display = 'block';
  }

  function handleNavSearchKeydown(e) {
    const box = document.getElementById('nav-search-suggestions');
    if (!box || box.style.display === 'none') return;

    const items = box.querySelectorAll('.suggestion-item');
    if (!items.length) return;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      activeSuggestionIndex = (activeSuggestionIndex + 1) % items.length;
      updateActiveSuggestion(items);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      activeSuggestionIndex = (activeSuggestionIndex - 1 + items.length) % items.length;
      updateActiveSuggestion(items);
    } else if (e.key === 'Enter') {
      if (activeSuggestionIndex >= 0 && activeSuggestionIndex < items.length) {
        e.preventDefault();
        items[activeSuggestionIndex].click();
      }
    } else if (e.key === 'Escape') {
      box.style.display = 'none';
    }
  }

  function updateActiveSuggestion(items) {
    items.forEach((item, idx) => {
      item.classList.toggle('active', idx === activeSuggestionIndex);
      if (idx === activeSuggestionIndex) {
        item.scrollIntoView({ block: 'nearest' });
      }
    });
  }

  function handleHeaderSearch(e) {
    e.preventDefault();
    const input = document.getElementById('nav-search-input');
    const query = input ? input.value.trim() : '';
    const box = document.getElementById('nav-search-suggestions');
    if (box) box.style.display = 'none';

    saveSearchQuery(query);
    openSearchModal(query);
  }

  function handleSuggestionClick(itemId) {
    const box = document.getElementById('nav-search-suggestions');
    if (box) box.style.display = 'none';
    const input = document.getElementById('nav-search-input');
    if (input) saveSearchQuery(input.value);
    handleResultClick(itemId);
  }

  /* ==========================================================================
     HERO IMAGE SLIDER CONTROLLER (5/6 Auto-Scrolling Slides Below Navbar)
     ========================================================================== */
  let heroCurrentSlide = 0;
  const HERO_TOTAL_SLIDES = 6;
  let heroSlideTimer = null;

  function initHeroSlider() {
    const track = document.getElementById('hero-slider-track');
    const prevBtn = document.getElementById('hero-slider-prev');
    const nextBtn = document.getElementById('hero-slider-next');
    const dots = document.querySelectorAll('.slider-dot');
    if (!track) return;

    function goToSlide(idx) {
      heroCurrentSlide = (idx + HERO_TOTAL_SLIDES) % HERO_TOTAL_SLIDES;
      track.style.transform = `translateX(-${(heroCurrentSlide * 100) / HERO_TOTAL_SLIDES}%)`;

      document.querySelectorAll('.hero-slide').forEach((slide, i) => {
        slide.classList.toggle('active', i === heroCurrentSlide);
      });

      dots.forEach((dot, i) => {
        dot.classList.toggle('active', i === heroCurrentSlide);
      });
    }

    function startTimer() {
      stopTimer();
      heroSlideTimer = setInterval(() => {
        goToSlide(heroCurrentSlide + 1);
      }, 4500);
    }

    function stopTimer() {
      if (heroSlideTimer) clearInterval(heroSlideTimer);
    }

    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        goToSlide(heroCurrentSlide - 1);
        startTimer();
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        goToSlide(heroCurrentSlide + 1);
        startTimer();
      });
    }

    dots.forEach(dot => {
      dot.addEventListener('click', () => {
        const idx = parseInt(dot.getAttribute('data-index'), 10) || 0;
        goToSlide(idx);
        startTimer();
      });
    });

    const container = document.getElementById('hero-slider');
    if (container) {
      container.addEventListener('mouseenter', stopTimer);
      container.addEventListener('mouseleave', startTimer);

      // Mobile Touch Swipe Handlers
      let startX = 0;
      let startY = 0;

      container.addEventListener('touchstart', e => {
        if (e.touches.length === 1) {
          startX = e.touches[0].clientX;
          startY = e.touches[0].clientY;
          stopTimer();
        }
      }, { passive: true });

      container.addEventListener('touchend', e => {
        if (e.changedTouches.length === 1) {
          const deltaX = e.changedTouches[0].clientX - startX;
          const deltaY = e.changedTouches[0].clientY - startY;
          if (Math.abs(deltaX) > 40 && Math.abs(deltaX) > Math.abs(deltaY)) {
            if (deltaX < 0) goToSlide(heroCurrentSlide + 1);
            else goToSlide(heroCurrentSlide - 1);
          }
          startTimer();
        }
      }, { passive: true });
    }

    goToSlide(0);
    startTimer();
  }

  window.UnionFoods = {
    addToCart,
    updateQty: updateCartQuantity,
    removeItem: removeFromCart,
    openCartDrawer,
    closeCartDrawer,
    toggleWishlist,
    openQuickView,
    selectQuickViewSize: (btn, size) => {
      document.querySelectorAll('#qv-size-group .size-pill-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    },
    addFromQuickView: (productId) => {
      const activeSizeBtn = document.querySelector('#qv-size-group .size-pill-btn.active');
      const size = activeSizeBtn ? activeSizeBtn.getAttribute('data-size') : null;
      addToCart(productId, 1, size);
      const modal = document.getElementById('quickview-modal');
      if (modal) modal.classList.remove('active');
    },
    openRecipeModal,
    adjustServings: adjustRecipeServings,
    scanBatch: scanBatchCode,
    checkPin: checkPincode,
    switchMap: switchMapLocation,
    setMapMode: setMapViewMode,
    startCheckout,
    completeOrder,
    openCertsModal: () => {
      const modal = document.getElementById('certs-modal');
      if (modal) modal.classList.add('active');
    },
    openFacilityModal: () => {
      const modal = document.getElementById('facility-modal');
      if (modal) modal.classList.add('active');
    },
    openSearchModal,
    closeSearchModal,
    applySearchChip: (query) => {
      const input = document.getElementById('modal-search-input');
      if (input) input.value = query;
      const clearBtn = document.getElementById('modal-search-clear');
      if (clearBtn) clearBtn.style.display = query ? 'flex' : 'none';
      saveSearchQuery(query);
      renderSearchResults(query);
    },
    clearSearchHistory,
    removeHistoryItem,
    handleHeaderSearch,
    handleSuggestionClick,
    handleResultClick,
    triggerSearchReSort: () => {
      const sel = document.getElementById('search-sort-select');
      if (sel) currentSearchSort = sel.value;
      const input = document.getElementById('modal-search-input');
      renderSearchResults(input ? input.value : '');
    },

    openWhatsApp: () => {
      const phone = '919876543210';
      const msg = encodeURIComponent('Hello Union Foods Team! I would like to know more about your products and home delivery.');
      window.open(`https://api.whatsapp.com/send?phone=${phone}&text=${msg}`, '_blank');
    }
  };

})();
